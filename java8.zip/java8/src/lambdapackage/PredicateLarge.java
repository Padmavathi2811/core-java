package lambdapackage;
import java.util.function.Predicate;
public class PredicateLarge {

	public static void main(String[] args) {
		Predicate<Integer>pob=(i)->i>10;
		//System.out.println("Numbers larger than 10: ");
		boolean b=pob.test(26);
		System.out.println(b);
		

	}

}
