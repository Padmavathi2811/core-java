package lambdapackage;
interface Addition{
	void add(int a, int b);
	
}

public class LambaWithAddMain {

	public static void main(String[] args) {
		Addition Aob=(a,b)->{
			int s;
			s=a+b;
			System.out.println("The sum of two numbers is "+s);
		};
		Aob.add(10,20);
		}
}
	
		