package mypack;

public class DataTypes {

	public static void main(String[] args) {
		boolean b=true;
		char ch='A';
		String name="Padmavathi";
		System.out.println("boolean value="+b);
		System.out.println("char value="+ch);
		System.out.println("String value= "+name);
				

	}

}
