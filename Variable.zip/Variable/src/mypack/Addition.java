package mypack;

public class Addition {

	public static void main(String[] args) {
		int num1,num2,ans;
		num1=34;
		num2=78;
		ans=num1+num2;
		System.out.println("ans=" +ans);
	}
}