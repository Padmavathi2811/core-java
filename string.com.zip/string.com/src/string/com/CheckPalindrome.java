package string.com;

import java.util.Scanner;

public class CheckPalindrome {

	public static void main(String[] args) {
		String A;
		String rev="";
		
		Scanner sc=new Scanner(System.in);
		System.out.println("String name= ");
		A=sc.nextLine();
		for(int i=A.length()-1;i>=0;i--)
		{
			rev=rev+A.charAt(i);
			
		}
		System.out.println("Reverse String= "+rev);
		
		if(A.equals(rev))
			
		{
			System.out.println("string is palindrome ");
			
		}
		else {
			System.out.println("string is not palindrome ");
			
		}
		
		
		
		

	}

}
