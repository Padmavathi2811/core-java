package com.edu;
class ThreadHello extends Thread{
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("Inside run "+Thread.currentThread());
			try {
				Thread.sleep(5000);
			
			} 
			catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		}
	}
}
	


public class ThreadMain {

	public static void main(String[] args)throws InterruptedException {
		System.out.println("Parent Thread" +Thread.currentThread());
		ThreadHello ob=new ThreadHello();
		ob.setName("first");
		ob.start();
		ob.join();
		ThreadHello ob1=new ThreadHello();
		ob1.setName("second");
		ob1.start();
	}
}

	