package mypack;

import java.util.Scanner;

public class FahrenheatToCelsius {

	public static void main(String[] args) {
		float fah,cel;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter fahrenheat value ");
		fah=sc.nextFloat();
		cel=((fah-32)*5/9);
		System.out.println(fah+ " fahrenheat converted into celsius "+cel );
	}
}
				
		


	


