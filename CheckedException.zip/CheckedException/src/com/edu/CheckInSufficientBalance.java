package com.edu;

import java.util.Scanner;
class BankException extends Exception{
	public BankException(String s) {
		super(s);
		}
	}
class Bank{
	private float amount;
	public Bank(int amount) {
		this.amount=amount;
		}
	public void depositAmount(float damount) {
		System.out.println("Your balance ="+amount);
		amount=amount+damount;
		System.out.println("Amount is deposited your balance="+amount);
	}
	public void withdrawAmount(float wamount) {
		System.out.println("Before withdraw amount="+amount);
		if(wamount>amount)
		{
			try {
				throw new BankException("Insufficient Balance");
			}catch(BankException e ) {
				e.printStackTrace();
			}
		}else {
			amount=amount-wamount;
			System.out.println("After withdraw your balance= "+amount);
		}
	}
}

	

public class CheckInSufficientBalance {

	public static void main(String[] args) {
		Bank bankobj=new Bank(1000);
		Scanner sc=new Scanner(System.in);
		int ch;
		float da,wa;
		while(true) {
			System.out.println("Bank options");
			System.out.println("1.DEPOSIT");
			System.out.println("2.WITHDRAW");
			System.out.println("enter your choice");
			ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("Enter the amount to deposit");
			       da=sc.nextFloat();
			       bankobj.depositAmount(da);
			       break;
			case 2:System.out.println("Enter amount to withdraw");
			       wa=sc.nextFloat();
			       bankobj.withdrawAmount(wa);
			       break;
			}
			System.out.println("Do you want to continue,yes/no");
			String option=sc.next();
			if(option.equalsIgnoreCase("no")) {
				System.exit(0);
			
		
		
				
			}
		}
		

	}

}


