package com.emp;

import java.util.Scanner;

class EmployeeArray{
    String empname;
     int empage;
     float empsalary;
     String empdept;  
    float annualsal;   

  void empInput(){
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter name");
       empname=sc.nextLine();
     System.out.println("Enter age");
      empage=sc.nextInt();
    System.out.println("Enter salary");
     empsalary=sc.nextFloat(); //ex : 40000
    
     System.out.println("Enter employee Department");
     sc.nextLine();
     empdept=sc.nextLine();

}

void empAnnualSalary(){
   annualsal=empsalary*12;
}

void empDeatails(){

		
		//array of objects
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter number of employee");
		int n=sc.nextInt();
		Employee eob[] = new Employee[n];//array of objects
		for(int i=0;i<n;i++) {
			eob[i]=new Employee(); //
		}
		//input employee data
		for(int i=0;i<n;i++) {
			eob[i].empInput();
		}
		//salary calcilation
		for(int i=0;i<n;i++) {
			eob[i].empAnnualSalary();
		}
		
		for(int i=0;i<n;i++) {
			eob[i].empDeatails();
		}
		
		
		
	}
 }
