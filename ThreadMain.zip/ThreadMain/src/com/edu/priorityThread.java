package com.edu;
class MyClass1 implements Runnable{
    @Override
     public void run(){
        System.out.println("Run method "+Thread.currentThread());
   }
}
public class priorityThread{
public static void main(String args[]){   
	System.out.println("Main Thread "+Thread.currentThread());
      MyClass1 ob=new MyClass1();
        Thread tob=new Thread(ob);
        tob.setName("firstThread");
        tob.start();
        MyClass1 ob1=new MyClass1();
        Thread tob1=new Thread(ob1);
        tob1.setPriority(Thread.NORM_PRIORITY); 
        tob1.setName("SecondThread");
        tob1.start();
        System.out.println("firstThread priority "+tob.getPriority()); 
        System.out.println("secondThread priority "+tob1.getPriority()); 
        
        System.out.println();
}
}

