package Mypack;

public class SumNaturalOddEven {
	public static void main(String[]args) {

	int i,nsum,oddsum,evensum;
	nsum=0;
	oddsum=0;
	evensum=0;
	
	i=1;
	while(i<=100) {
	     nsum=nsum+i;  
	     if(i%2==0) {  
	          evensum=evensum+i;
	     }
	     if(i%2!=0) {  
	    	 oddsum=oddsum+i;
	     }
	     i=i+1;
	}
	
	System.out.println("Natural sum (1 to 100 )"+nsum);
	System.out.println("Oddsum="+oddsum);
	System.out.println("Evensum="+evensum);
	
}
}
