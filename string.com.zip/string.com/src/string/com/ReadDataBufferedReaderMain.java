package string.com;
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;

class Student1{
	private int sid;
	private String sname;
	private float sfees;
	
	public void inputStudent1() throws IOException {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter student1 id"); 
		sid=Integer.parseInt(br.readLine());
		System.out.println("Enter name");
		sname=br.readLine();
		System.out.println("Enter fees");
		sfees=Float.parseFloat(br.readLine());
		
	}
	public void displayStudent1() {
		System.out.println("Name="+sname);
		System.out.println("Student1 id="+sid);
		System.out.println("Student1 fees="+sfees);
	}
	
}

public class ReadDataBufferedReaderMain {

	public static void main(String[] args) throws IOException {
		Student1 sob=new Student1();
		sob.inputStudent1();
		
        sob.displayStudent1();
	}

}




