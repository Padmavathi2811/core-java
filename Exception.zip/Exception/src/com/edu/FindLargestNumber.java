package com.edu;

import java.util.Scanner;
class FindLarge{
	private int num1,num2;
	public void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 2 nums ");
		num1=sc.nextInt();
		num2=sc.nextInt();
	}
	
	public void findLarge() {
		if(num1>num2)
		{
			System.out.println(num1+" �s larger");
		}
		else {
			System.out.println(num2 + " is largest");
		}
	}
}

public class FindLargestNumber {

	public static void main(String[] args) {
		
		FindLarge ob=new FindLarge();
		ob.inputData();
		ob.findLarge();
		
	}
}
		

