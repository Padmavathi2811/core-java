package edu.com;
import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int ar[];
		int key, pos=-1;
		int size;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter array size");
		size=sc.nextInt();
		ar=new int[size]; 
		

		System.out.println("array elements");
		for(int i=0;i<ar.length;i++) {
			ar[i]=sc.nextInt();
		}
		
		
		
		System.out.println("Enter key element");
		key=sc.nextInt();
		
		
		for(int i=0;i<ar.length;i++) {
			if(key==ar[i]) {
				pos=i;  
				break;
			}
		}
		
		if(pos>=0) {
			System.out.println("Successful search");
			System.out.println(key+" found at position "+(pos+1));
		}
		else {
			System.out.println(key+ " not found ");
			System.out.println("Unsuccessful search");
		}
		
	}



	}


