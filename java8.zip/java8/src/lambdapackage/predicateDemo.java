package lambdapackage;
import java.util.function.*;

public class predicateDemo {

	public static void main(String[] args) {
		Integer []arr={8,9,10,11,2,3,4,12,1};
		Predicate<Integer>gt=(i) -> i>6;
        System.out.println("Numbers greater than 5 :");
        myMethod(gt,arr);
        int ar[]= {10,20,30,40};
		System.out.println("Array elements are");
		for(int i:ar) {
		    	   System.out.println(i);
		       }
		   }
		   static void myMethod(Predicate<Integer> p, Integer []arr)
		   {
		           for(Integer i:arr){
		                   if(p.test(i))
		                	   System.out.println(i+" ");
		            }
		   }
		   
	}


