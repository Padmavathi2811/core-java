package Exampleprime;

public class CheckPrime {

	public static void main(String[] args) {
		

	}

}
