package com.edu;

public class blocks {
	static {
		System.out.println("Static block");
		
	}
	{
		System.out.println("Normal block");
		
	}
	blocks(){
		System.out.println("Constructor block");
	}

	public static void main(String[] args) {
		blocks obj=new blocks();

	}

}
