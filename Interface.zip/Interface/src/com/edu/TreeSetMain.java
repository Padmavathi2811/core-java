package com.edu;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetMain {

	public static void main(String[] args) {
		TreeSet<Float>tob=new TreeSet<Float>();
		tob.add(45.7f);
		tob.add(23.7f);
		tob.add(21.7f);
		tob.add(65.8f);
		System.out.println(tob);
		Iterator<Float> it=tob.descendingIterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
		}
		
		

	