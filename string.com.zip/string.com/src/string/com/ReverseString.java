package string.com;

public class ReverseString {

	public static void main(String[] args) {
		String S="mother";
		
		for(int i=S.length()-1;i>=0;i--) {
			System.out.print(S.charAt(i));
			
			
			
		}
		

	}

}
