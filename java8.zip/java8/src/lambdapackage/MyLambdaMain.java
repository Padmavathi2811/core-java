package lambdapackage;
interface MyDisplay{
	void display();
}

public class MyLambdaMain {

	public static void main(String[] args) {
		

	}

}
