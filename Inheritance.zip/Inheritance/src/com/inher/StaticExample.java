package com.inher;

public class StaticExample {
		
		int i;
	  StaticExample(){
	     System.out.println("No argument constructor");
	  }
		
	  StaticExample(int i){
		  this();
		  this.i=i;
		  System.out.println("One argument constructor()"+i);
		  
	  }
		public static void Main (String[] args) {
			
			StaticExample ob=new StaticExample(3);
			

		}

	


	

	}


