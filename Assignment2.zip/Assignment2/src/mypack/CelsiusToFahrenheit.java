package mypack;

import java.util.Scanner;

public class CelsiusToFahrenheit {

	public static void main(String[] args) {
		float fah,cel;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter celsius value ");
		cel=sc.nextFloat();
		fah=((cel*9)/5)+32;
		System.out.println(cel+ " Celsius converted into Fahrenheit "+fah );
	}
}
	


