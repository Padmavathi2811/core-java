package string.com;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class UserValidation{
	private String uname;
	private String upass;
	
	public void inputData() throws IOException {
		InputStreamReader is=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(is);
		
		
		
		System.out.println("Enter name");
		uname=br.readLine();
		System.out.println("Enter password");
		upass = br.readLine();
		}
	
	public void userValidate() { 
		if(uname.equals("admin") && (upass.equals("admin123"))){
			
			System.out.println("Username and password is valid");
		}
		else {
			System.out.println("Invalid user");
		}
	}
}

public class StringFunctions {

	public static void main(String[] args) throws IOException {
		UserValidation ob=new UserValidation();
		ob.inputData();
		ob.userValidate();
	}
}

	





