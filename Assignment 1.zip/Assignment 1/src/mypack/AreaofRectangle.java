package mypack;

public class AreaofRectangle {

	public static void main(String[] args) {
		int lenght,breadth,area;
		lenght=10;
		breadth=14;
		area=lenght*breadth;
		System.out.println("lenght of rectangle= " +lenght + "and breadth of rectangle= "+breadth + " is " +area +" squnits");
		

	}

}
