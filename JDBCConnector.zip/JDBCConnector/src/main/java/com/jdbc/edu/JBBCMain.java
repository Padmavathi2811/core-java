package com.jdbc.edu;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;

public class JBBCMain {

	public static void main(String[] args) {
		
				String driver = "com.mysql.cj.jdbc.Driver";
				String un = "root";
				String pass = "root";
				String url = "jdbc:mysql://localhost:3306/padmavathidatabase";
				
				try {
					Class.forName(driver);
					Connection con = DriverManager.getConnection(url,un,pass);
					Statement stmt = con.createStatement();
					
					String s = "select *from employee";
					ResultSet rs = stmt.executeQuery(s);
					
					System.out.println("eid\tename\tesalary\tedept");
					while(rs.next()) {
						System.out.println(rs.getInt("eid")+"\t"+rs.getString("ename")+"\t"+rs.getFloat("esalary")+"\t"+rs.getString("edept"));
					}
					}catch(Exception e) {
					e.printStackTrace();
				}
			}

		


		

	}


