package com.service;

import java.util.List;

import com.entity.Books;

public interface BooksService {

	List<Books> getAllBooks();

	Books registerBook(Books books);

	Books updateAuthorToBook(Integer bookid, Integer authorid);

	Books updatePublisherToBook(Integer bookid, Integer publisherid);

	void deleteBookById(Integer bookid);

	Books updateBook(Integer bookid, Books book);

}
