package string.com;
 class Student {

	
			private int sid; 
			private String sname; 
			private static String cname; 
			static {
				cname="MSRIT";
			}
			
			public Student(int sid, String sname) {
				this.sid=sid;
				this.sname=sname;
				
			}
			public void studentDisplay() {
				System.out.println("Student id="+sid);
				System.out.println("Student Name="+sname);
				System.out.println("Student college name="+cname);
			}
		}

		public class StudentMain {

			public static void main(String[] args) {
				Student sob1=new Student(1,"Mohammed");
				Student sob2=new Student(2,"Prasanth");
				Student sob3=new Student(3,"Reshma");
				sob1.studentDisplay();
				sob2.studentDisplay();
				sob3.studentDisplay();
			}

		

	}


