package com.edu;

public class SwapNumbers {

	public static void main(String[] args) {
		

	}
}