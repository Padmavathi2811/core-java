package com.edu;

public class MainApp2 {

	public static void main(String[] args) {
		int a=10, b=0,c=0;
		String s=null;
		int ar[]=new int[2];
		System.out.println("Before division");
		try {
		c=a/b;
		}
		catch(ArithmeticException e) {
			System.out.println("the number cannot be divided by zero");
			e.printStackTrace();
		}
		finally {
			System.out.println("finally");
		}
		System.out.println("After division "+c);
		int l=0;
		try {
	      l=s.length();
		}
		catch(NullPointerException e) {
			e.printStackTrace();
		}
		System.out.println("Length of string "+l);
	  try {
		ar[2]=45;
	  }
	  catch(ArrayIndexOutOfBoundsException e) {
		  e.printStackTrace();
	  }
	}



	}


