package com.jdbc.edu;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
		
		public class JDBCOperations {
		private static Connection connection;
		private static Scanner sc;
		private static ResultSet rs;
		private static PreparedStatement pst;
		private static int id;
		private static  String name,sel;

			public static void addRecord() throws SQLException {
				
				connection = JDBCConnection.getConnection(); 
				
				sc = new Scanner(System.in);
				System.out.println("Enter name");
				name = sc.nextLine();
				System.out.println("Enter student id");
				id = sc.nextInt();
				
				sel = "select * from student where sid=?";
				
				pst = connection.prepareStatement(sel);
				pst.setInt(1, id);
				rs = pst.executeQuery(); 				
				
				if(!rs.next()) { 
					String ins = "insert into student values(?,?)";
					
					pst = connection.prepareStatement(ins);
					pst.setInt(1, id);
					pst.setString(2, name);
					int retval = pst.executeUpdate(); 
					if(retval>0) {
						System.out.println("Record inserted");
					}else {
						System.out.println("Error occured");
					}
			}
				else {
					System.out.println(id+" already exists ");
				}
								
			 }
			public static void displayRecord() throws SQLException {
				connection=JDBCConnection.getConnection();
				String sel="select * from student";
				pst = connection.prepareStatement(sel);
				rs=pst.executeQuery();
				System.out.println("SID\tSNAME");
				while(rs.next()) {
					System.out.println(rs.getInt(1)+"\t"+rs.getString(2));
				}
			}
			public static void updateRecord() throws SQLException {
				connection = JDBCConnection.getConnection();
				sc=new Scanner(System.in);
				System.out.println("Enter the name to change");
				name = sc.nextLine();
				System.out.println("Enter id");
				id = sc.nextInt();
				
				sel = "select * from student where sid=?";
				pst = connection.prepareStatement(sel);
				pst.setInt(1, id);
				rs = pst.executeQuery();
				
				if(rs.next()) { 
					String upd ="update student set sname=? where sid=?";
					pst = connection.prepareStatement(upd);
					pst.setString(1, name);
					pst.setInt(2, id);
					int retval=pst.executeUpdate();
					
					if(retval > 0) {
						System.out.println("Recorded is updated ");
					}else {
						System.out.println("Error occurred");
					}
					
				}else {
					System.out.println("Record not exists");
				}
				
				
			}
							
			public static void deleteRecord() throws SQLException {
				
					connection=JDBCConnection.getConnection();
					sc=new Scanner(System.in);
					System.out.println("Enter id ");
					id=sc.nextInt();
				    sel= "select * from student where sid=?";
					
					pst=connection.prepareStatement(sel);
					pst.setInt(1, id);
					rs=pst.executeQuery();
					if(rs.next()) {
						String delete="delete from student where sid=?";
						pst=connection.prepareStatement(delete);
						pst.setInt(1, id);
						int retval=pst.executeUpdate();
						if(retval>0) {
							System.out.println("Record deleted");
						}else {
							System.out.println("Deletion Error!");
						}
					}
			}
		}
					

				
				
			
		


	


