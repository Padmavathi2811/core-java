package Mypack;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		int num,cube,rem,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		num=sc.nextInt();
		while(num>0)
		{
			rem=num%10;
			cube=rem*rem*rem;
			sum=sum+cube;
			num=num/10;
		}
		if(num==sum)
		{
			System.out.println(num+"  is an armstrong number");
		}
		else
		{
			System.out.println(num+"  not an armstrong number");
			
		}
		

	}

}
