package lambdapackage;
import java.util.function.*;

public class FunctionDemo {

	public static void main(String[] args) {
		Function<String,Integer>fn=(str)->str.length();
		String s="Hyderabad";
		System.out.println("Number of characters in string= "+fn.apply(s));
		
		
		Function<String,String> fs=(str)->(str.toUpperCase());
		System.out.println("to upper case "+fs.apply(s));
		
		
		Function<String,String> fc=(str)->(str.concat("Telangana"));
		System.out.println("concat "+fc.apply(s));
		
		

	}

}
