package lambdapackage;
interface Add{
	int add(int a, int b);
}

interface Subtraction{
	int sub(int a, int b);
}

interface Multiplication{
	int multiply(int a, int b);
}


public class LambdaReturnMain {
	public static void main (String[]args) {
	
				Add aob=(a,b)->(a+b);
				
				int sum=aob.add(10,20); 
				System.out.println("sum="+sum);
				
				Subtraction sob=(a,b)->(a-b);
				System.out.println("Difference="+sob.sub(20,10));
				
				Multiplication mob=(a,b)->(a*b);
				System.out.println("Product="+mob.multiply(10, 20));
			}
		}

		

	