package lambdapackage;
import java.util.function.Predicate;

public class PredicateMain {
	public static void main(String args[]) {
	Predicate<Integer> pob=(i)->(i>20);
	boolean b=pob.test(5);
	System.out.println(b);
	}
}
