package com.inher;

import java.util.Scanner;

class Empl{
	private int Eid;
	private String Ename;
	static String cname;
	static {
		cname="edubridge";
	}
	public void inputEmployee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Ename");
		Ename=sc.nextLine();
		System.out.println("enter Eid");
		Eid=sc.nextInt();
	}
	public void Empldetails() {
		System.out.println("name="+Ename);
		System.out.println("id="+Eid);
		System.out.println("cname="+cname);
		
		
	}
	
}

public class Employee {

	public static void main(String[] args) {
		Empl Eobj[]= new Empl[3];
		for(int i=0;i<Eobj.length;i++) {
			Eobj[i]=new Empl();
			Eobj[i].inputEmployee();
		}
		System.out.println("all Employee details");
		for(int i=0;i<Eobj.length;i++) {
			Eobj[i].Empldetails();
			
			
			
			
		}
		
		
		
		

	}

}



