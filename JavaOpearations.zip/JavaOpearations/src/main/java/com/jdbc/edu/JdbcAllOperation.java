package com.jdbc.edu;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcAllOperation {
private static Connection connection;
private static Statement st;
private static ResultSet rs;
private static int eid;
private static String ename;
private static String esalary;
private static String edept;

private static Scanner sc;


	public static void displayRecord() throws SQLException {
		connection = DatabaseConnection.getConnection();
		st = connection.createStatement();
		
		String select = "select * from employee";
		rs = st.executeQuery(select);
		
		
		System.out.println("employee Id\temployee name\temployee salary\temployee department");
		while (rs.next()) {
			System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2));
			
		}
}
	public static void addRecord() throws SQLException {
		connection=DatabaseConnection.getConnection();
	      st = connection.createStatement();
		sc = new Scanner(System.in);
		
		System.out.println("Enter employee name to add record");
		ename = sc.nextLine();
		
		System.out.println("Enter employee id");
		eid = sc.nextInt();
		String select = "select * from employee where eid="+eid;
	     rs = st.executeQuery(select);	
	
	    if(!rs.next()) {
		
	String insert = "insert into employee values("+eid+",'"+ename+"'"+esalary+",'"+edept+"')";
	//System.out.println("insert="+insert);
		
		    int i = st.executeUpdate(insert);
		    
		    if(i>0) {
		    	System.out.println("Record is inserted successfully");
		    }
		    else {
		    	System.out.println("Record is not inserted successfully");
		    }
	    }
	    else {
	    	System.out.println(eid+" already exists");
	    }
		
		
	}
	public static void updateRecord() throws SQLException {
		connection=DatabaseConnection.getConnection();
		st = connection.createStatement();
		sc = new Scanner(System.in);
		System.out.println("Enter name to change");
		ename = sc.nextLine();
		
		System.out.println("Enter id");
		eid = sc.nextInt();
		
		String select = "select * from employee where eid="+eid;
		
		rs=st.executeQuery(select);
		if(rs.next()) {
			String update="update employee set ename='"+ename+"' where eid="+eid;
		    int rval=st.executeUpdate(update);
		    
		    if(rval>0) {
		    	System.out.println("Record is updated successfully");
		    }else {
		    	System.out.println("Not updated , Error !!!!");
		    }
		
		}
		else {
			System.out.println(eid+" employee id not exist");
		}
		
	}
	public static void deletRecord() throws SQLException {
		connection=DatabaseConnection.getConnection();
		st = connection.createStatement();
		sc = new Scanner(System.in);
		
		
		System.out.println("Enter id");
		eid = sc.nextInt();
		
		String select = "select * from employee where eid="+eid;
		
		rs=st.executeQuery(select);
		if(rs.next()) {
			String delete="delete from employee where eid="+eid;
		    int rval=st.executeUpdate(delete);
		    
		    if(rval>0) {
		    	System.out.println("Record is deleted successfully");
		    }else {
		    	System.out.println("Not deleted  , Error !!!!");
		    }
		
		}
		else {
			System.out.println(eid+" employee id not exist to delete record");
		}
		
}

}
		
		
		
	
