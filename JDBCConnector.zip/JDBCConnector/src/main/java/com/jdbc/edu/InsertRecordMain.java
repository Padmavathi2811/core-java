package com.jdbc.edu;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InsertRecordMain {

	public static void main(String[] args) {
				//make a connections
				String driver="com.mysql.cj.jdbc.Driver";
				String url = "jdbc:mysql://localhost:3306/padmavathidatabase";
				String un = "root";
				String pass = "root";
				
				String employeename;
				int employeeid;
				float employeesalary;
				String employeedepartment;
				Scanner sc = new Scanner(System.in);
				
				System.out.println("Enter employee name");
			    employeename = sc.nextLine();
				
				System.out.println("Enter id of employee");
				employeeid = sc.nextInt();
				
				System.out.println("Enter salary of employee");
				employeesalary=sc.nextFloat();
				
				System.out.println("Enter department of employee");
				
				employeedepartment=sc.next();
				
				try {
					Class.forName(driver);
					Connection con = DriverManager.getConnection(url, un, pass);
					Statement st = con.createStatement();
					
					String select = "select * from employee where eid="+employeeid;
				    ResultSet rs = st.executeQuery(select);	
				
				    if(!rs.next()) {
					
				String insert = "insert into employee values("+employeeid+",'"+employeename+"',"+employeesalary+",'"+employeedepartment+"')";
				System.out.println(insert);
				//System.out.println("insert="+insert);
					
					    int i = st.executeUpdate(insert);
					    
					    if(i>0) {
					    	System.out.println("Record is inserted successfully");
					    }
					    else {
					    	System.out.println("Record is not inserted successfully");
					    }
				    }
				    else {
				    	System.out.println(employeeid+" already exists");
				    		
				    }
				    					
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
	}


