package com.edu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Palindrome
{
	public static int checkPalindrome(int num)
    {
		int n,digit,rev=0;
		n=num;
        while (num>0) {              
        	digit = num % 10;     
            rev = (rev * 10) + digit ;
            num = num / 10;
        }
       if (n == rev) {
           return 1;
        }
        else {
           return 0;
        }
   }
	public static void nextPalindrome(int num)
	{
		while(checkPalindrome(num)==0)
	       {
	       	num=num+1;
	       }
		System.out.println(num);
	}
}
public class nxtpal{
public static void main(String[] args) throws IOException {
	 Palindrome pob=new Palindrome();
	 BufferedReader bufferreader=new BufferedReader(new InputStreamReader(System.in));
	 System.out.println("Enter the number : ");
	 int num =Integer.parseInt(bufferreader.readLine()) ;
	 pob.nextPalindrome(num);
	 }
}
