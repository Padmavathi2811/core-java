package com.edu;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class EmployeeMain {

	public static void main(String[] args) {
		Employee eob=new Employee();
		
		Configuration con=new Configuration().configure().addAnnotatedClass(Employee.class);
		ServiceRegistry reg=new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory(reg);
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		
		String s="from Employee ";
		Query q=session.createQuery(s);
		List list=q.list();

		Iterator<Employee> e=list.iterator();

		System.out.println("Empid\tEmpName\tEmpSalary\tEmpdept");
		while(e.hasNext()){
		  Employee eobj=e.next();
		  System.out.println(eobj.getEmpid()+"\t"+eobj.getEmpname()+"\t"+eobj.getEmpsalary()+"\t"+eobj.getEmpdept());
		}
		          //Maximum
		String maxsalary="select max(empsalary) from Employee";
		
		Query qmax=session.createQuery(maxsalary);
		List lmax=qmax.list();
		
		System.out.println("Maximum salary ="+lmax.get(0));
		
		      //Minimum
		String minfees="select min(empsalary) from Employee";
		Query qmin=session.createQuery(minfees);
		List lmin=qmin.list();
		System.out.println("Minimum salary="+lmin.get(0));
		
		    //total salary
		
		String tfees="select sum(empsalary) from Employee";
		Query qtfees=session.createQuery(tfees);
		List ltfees=qtfees.list();
		System.out.println("Total salary="+ltfees.get(0));
		
		    //Average
		
		String afees="select avg(empsalary) from Employee";
		Query qafees=session.createQuery(afees);
		List lafees=qafees.list();
		System.out.println("Average salary="+lafees.get(0));
	
		tx.commit();
	}



	}


