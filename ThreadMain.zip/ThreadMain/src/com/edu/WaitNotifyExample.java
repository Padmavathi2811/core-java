package com.edu;
class ThreadSum extends Thread{
	int total;
	public void run() {
		System.out.println("Inside run method");
		synchronized (this) {
			for(int i=1;i<=100;i++) {
				total=total+i;
			}
			notify();
		}
		
		}
}

public class WaitNotifyExample {

	public static void main(String[] args) {
		ThreadSum tob=new ThreadSum();
		tob.start();
		synchronized (tob) {
			try {
				System.out.println("before wait method");
				tob.wait();
				System.out.println("Total of 1 to 100"+tob.total);
			}catch(InterruptedException e) {
				e.printStackTrace();
				
			}
		}
		

	}

}