package com.edu;
import java.util.Scanner;
class NextPalindrome
{
   
 static int isPalindrome(int num)
    {
        int n, rem, rev = 0;
        n = num;    
        while (num != 0) {
            rem = num % 10;
            rev = (rev * 10) + rem ;
            num = num / 10;
        }
        if (n == rev) {
            return 1;
        }
        else {
            return 0;
        }      }
        
     public static void  nextPal(int num)
     {
    	 while (isPalindrome(num) == 0) {
             num = num + 1;
         } 
    	 System.out.println("Next palindrome is " +num);
     }
         
    public static void main(String[] args)
    {
       int number;
        NextPalindrome np = new NextPalindrome();
        Scanner scanner = new Scanner(System.in);
        	System.out.println("Enter the number");	
        	number = scanner.nextInt();
            np.nextPal(number);
    }
}


