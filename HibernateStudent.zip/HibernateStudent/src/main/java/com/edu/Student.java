package com.edu;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")


public class Student {
	@Id
	@GeneratedValue
	@Column(name="sid")
	private int sid;
	@Column(name="sname",length=20)
	private String sname;
	
	public Student() {
		super();
	}
	public int getsid() {
		return sid;
	}
	public void setsid(int sid) {
		this.sid = sid;
	}
	public String getsname() {
		return sname;
	}
	public void setsname(String sname) {
		this.sname = sname;
	}
	
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + " ]";
				
	}
	
	

}


