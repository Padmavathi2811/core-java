package com.edu;

import java.util.Scanner;

public class ArrayExample {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		int arr[]=new int[5];
		System.out.println("enter 5 elements ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("array elements are ");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		try {
			System.out.println("arr[5]");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		
		}

	}


