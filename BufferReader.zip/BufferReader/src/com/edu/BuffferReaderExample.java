//BufferedReader Example
package com.edu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Employee {
int age;
String name;
float salary;
char gen;

void readData() throws IOException{
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("Enter name");

   name=br.readLine();   //String
   System.out.println("Enter age");
   age = Integer.parseInt(br.readLine());  //22   //string cannot be assigned to int
   System.out.println("Enter salary");
   salary=Float.parseFloat(br.readLine());  //5671.60
   System.out.println("Enter gender");
  // gen=br.readLine().charAt(0); // (char)br.read(); //
   gen=(char)br.read(); 
  
}

void displayEmployee() {
	System.out.println("name="+name);
	System.out.println("age="+age);
	System.out.println("salary="+salary);
	System.out.println("gender="+gen);
}
}

public class BuffferReaderExample {
	

	public static void main(String[] args) throws IOException {
Employee ob = new Employee();
		ob.readData();
		ob.displayEmployee();
	}

}

