package Exampleprime;

import java.util.Scanner;

public class PrimeorNot {

	public static void main(String[] args) {
		int n,m,flag=0;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		n=sc.nextInt();
		if(n==0||n==1) {
			System.out.println("is not a prime");
		}else {
			for(int i=2;i<=n/2;i++) {
				if(n%i==0) {
					System.out.println("is not a prime");
					flag=1;
					break;
				}
			}
			if (flag==0)
			{
				System.out.println("is a prime ");
				}
			}
		}

	}


