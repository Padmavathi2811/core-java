package com.constr;
import java.util.Scanner;


class Stud{
	private int sid;
	private String sname;
	public Stud() {
		sid=0;
		sname=null;
	}
	Stud(int sid, String sname){
		this.sid=sid;
		this.sname=sname;
	}
	
	void studDisplay() {
		System.out.println("Id="+sid);
		System.out.println("Name="+sname);
	}
	public void inputData() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		sname=sc.nextLine();
		System.out.println("Enter id");
		sid=sc.nextInt();
	}
}
public class Student1Main{

	public static void main(String[] args) {
		Stud s1=new Stud(1,"Kiran"); //calls constructor
		Stud s2=new Stud(2,"Manoj");
          s1.studDisplay();
          s2.studDisplay();
          
          Stud s3=new Stud();
          s3.inputData();
          s3.studDisplay();
	}
}
