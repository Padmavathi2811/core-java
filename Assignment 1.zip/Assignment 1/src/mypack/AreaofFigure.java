package mypack;
import java.util.Scanner;

public class AreaofFigure{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Length : ");
	    float length=sc.nextFloat();
		System.out.println("Enter the breadth : ");
		float breadth=sc.nextFloat();
		float arearec=length*breadth;
		System.out.println("Area of the rectangle : "+arearec+"sqrunits");
		System.out.println("Enter the side : ");
		float side=sc.nextFloat();
		float areasqr=side*side;
		System.out.println("Area of square " +areasqr+"sqrunits");
	    System.out.println("Enter the radius : ");
		float radius=sc.nextFloat();
	    float areacir=3.14159f*radius*radius;
		System.out.println("Area of a circle : "+areacir+"sqrunits");
		System.out.println("Enter the height : ");
		float height=sc.nextFloat();
		float areatri=0.5f*breadth*height;
		System.out.println("Area of a Triangle : "+areatri+"sqrunits");
		sc.close();
	} 
	
	
}




	

		 � � 

		 
		

	


