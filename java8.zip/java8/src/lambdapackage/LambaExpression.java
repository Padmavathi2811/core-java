package lambdapackage;
public class LambaExpression {
	public static void main(String[] args) {
		Runnable rob=new Runnable() {
			@Override
			public void run() {
				System.out.println("run method");	
			}
		};
		Thread t=new Thread(rob);
		t.start();
		Runnable robj=()->{
			System.out.println("run method is called");
			System.out.println("another statement");
		};
	       Thread tobj=new Thread(robj);
          tobj.start();
	}

}



