package com.edu;

import java.util.Scanner;

class PrimeNumber{
	private int number;
	
	public void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("�nter the number to check prime or not");
		number = sc.nextInt();
	}


public void checkPrime() {
	 //prime has got 2 factors
	//Prime is divisile by 1 and itself
	//5  is divisible by 1 and 5, 3, 7 ,11,
	//6 is divisible by 1 2 3 6
	int count=0;
	if(number==0) {
		System.out.println("is not prime");
	}
	else {
		for(int i=1;i<=number;i++) {
			if(number%i==0)
			{
				count++;
			}
		}
	}
	if(count == 2) {
		System.out.println(number+ " is prime number");
	}
	else {
		System.out.println(number +"is not prime number" );
	}
}	
}
	
public class PrimeMain {

	public static void main(String[] args) {
		PrimeNumber np=new PrimeNumber();
		np.inputData();
		np.checkPrime();

	}
}
