package Mypack;

import java.util.Scanner;

public class HarshadNumber {

	public static void main(String[] args) {
		int num,k,sum=0,digit;
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the number: ");
		num=sc.nextInt();
		k=num;
		while(num>0) {
			digit=num%10;
			sum=sum+digit;
			num=num/10;
		}
		if(k%sum==0)
		{
			System.out.println(k+ " it is a Harshad Number");
		}
		else {
			System.out.println("its not a Harshad Number");
		}
		

	sc.close();
	}
}
	


