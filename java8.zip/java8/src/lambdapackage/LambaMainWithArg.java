package lambdapackage;


interface StringDisplay{
	void strDisplay(String s);
}

public class LambaMainWithArg {

	public static void main(String[] args) {

     
		StringDisplay obj=(s)->{
			System.out.println("Hai "+s);
		};
		obj.strDisplay("sony");
	}

}

