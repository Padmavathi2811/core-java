package Mypack;
import java.util.Scanner;



public class ArrayDemo {

	public static void main(String[] args) {
		
		int ar[]=new int[5];
		int sum=0;
		float avg=0;
		
		System.out.println("first element="+ar[0]);
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter 5 numbers");
		for(int i=0;i<5;i++) {  
			ar[i]=sc.nextInt();
		}
		
		System.out.println("Entered elements are");
		for(int i=0;i<5;i++) {
		   System.out.println(ar[i]);
		}
		
		
		
		for(int i=0;i<ar.length;i++) {
			sum=sum+ar[i];
		}
		
		System.out.println("sum="+sum);
	
		avg=(float)sum/5;
		System.out.println("Average="+avg);
    }

	}


