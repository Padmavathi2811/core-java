package com.edu;

public class MultipleTryWithMultipleCatch {

	public static void main(String[] args) {
		int a=10, b=0,c=0;
		int ar[]=new int[4];
		System.out.println("Starting Program");
		try {
			c=a/b;  //exception
			
		}catch(ArithmeticException e) {
			e.printStackTrace();
		}
		
		try {
			ar[4]=67; //exception
		}
		catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		System.out.println("end of the program");
	}   





	}


