package lambdapackage;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamApiMain {

	public static void main(String[] args) {
		List<Integer> lst = new ArrayList<Integer>();
		
	    for(int i=1;i<=20;i++) {
	    	lst.add(i);
				}
	    
		Stream<Integer> sm = lst.stream(); 
		List<Integer>lst1 = sm.filter(i->i>10).collect(Collectors.toList());
		System.out.println(lst1);
		
		lst1.forEach(el->System.out.println(el));
		         
	}

}
