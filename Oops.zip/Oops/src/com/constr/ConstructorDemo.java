package com.constr;
class Student{ 
	 int sid;
	String sname;
	float sfees;
 
	 Student(){
		System.out.println("Constructor ");
	    sid=101;
	    sname="Radhika";
	    sfees=10000.50f;
	 }
	
}

public class ConstructorDemo{

	public static void main(String[] args) {
		int totalfees;
         Student sob=new Student(); 
         System.out.println("sid="+sob.sid);
         System.out.println("sname="+sob.sname);
         System.out.println("fees="+sob.sfees);
          
	}

}


