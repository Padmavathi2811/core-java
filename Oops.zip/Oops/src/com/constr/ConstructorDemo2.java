package com.constr;
class Student1{ 
	 int sid;
	String sname;
	float sfees;
   
	 Student1(){// constructor with no arg
		System.out.println("Constructor is called on creation of an object implicitly");
	    sid=101;
	    sname="Radhika";
	    sfees=10000.5f;
	 
	 }
	             
	 Student1(int sid, String sname, float sfees){  //constructor with argument
		  this.sid=sid;  //this is an implicit object
		   this.sname=sname;
		   this.sfees=sfees;
		 
	 }
	
}
public class ConstructorDemo2 {
	public static void main(String[] args) {
		int totalfees;
          Student1 sob=new Student1(); 
          Student1 sob1=new Student1(102,"malathi",8764.3f); 
          Student1 sob2=new Student1(103,"anusha",7654.2f);

          System.out.println("sid="+sob.sid);
          System.out.println("sname="+sob.sname);
          System.out.println("fees="+sob.sfees);
        
System.out.println("sid="+sob1.sid);
          System.out.println("sname="+sob1.sname);
          System.out.println("fees="+sob1.sfees);
          
          
          System.out.println("sid="+sob2.sid);
          System.out.println("sname="+sob2.sname);
          System.out.println("fees="+sob2.sfees);
         
	}

}


