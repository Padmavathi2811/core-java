package com.edu;
import java.util.Scanner;

public class AreaUsingSwitch {

	public static void main(String[] args) {
		String shape;
		float area;
		Scanner sc=new Scanner(System.in);
		System.out.println("----menu---");
		System.out.println("enter rectangle");
		System.out.println("enter circle");
		System.out.println("enter triangle");
		System.out.println("enter square");
		shape=sc.next();
		switch(shape)
		{
		case "rectangle":
			float length,breadth;
			System.out.println("enter length and breadth");
			length=sc.nextFloat();
			breadth=sc.nextFloat();
			area=length*breadth;
			System.out.println("area of rectangle"+area);
			break;
		case "circle":
			float radius;
			System.out.println("enter radius");
			radius=sc.nextFloat();
			area=3.41f*radius*radius;
			System.out.println("area of circle"+area);
			break;
		case "triangle":
			float height,base;
			System.out.println("enter height and base");
			height=sc.nextFloat();
			base=sc.nextFloat();
			area=0.5f*height*base;
			System.out.println("area of triangle"+area);
			break;
		case "square":
			float side;
			System.out.println("enter side");
			side=sc.nextFloat();
			area=side*side;
			System.out.println("area of square"+area);
			break;
			default:
				System.out.println("invalid");
				break;
		}
	}


	}


