package lambdapackage;
interface MyInterface{
	void display();
	default void fun1() {
		System.out.println("default method");
	}
	
}
class MyClass implements MyInterface{
	public void display() {
		System.out.println("Display method");
		
	}
}

public class InterfaceMainClass {

	public static void main(String[] args) {
		MyClass ob=new MyClass();
		ob.display();
		ob.fun1();
		
	}

}
