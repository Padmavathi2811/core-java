package com.edu;

class MyClass extends Thread{
	public void run() {
		System.out.println("Inside run method"+Thread.currentThread());
		
	}
}

public class ThreadsDemo {
	public static void main(String[]args) {
		System.out.println("the thread given JVM "+Thread.currentThread());
		MyClass tob=new MyClass();
		tob.start();
		MyClass tob1=new MyClass();
		tob1.start();
	}

}
