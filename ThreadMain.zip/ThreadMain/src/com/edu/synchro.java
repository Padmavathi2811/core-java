package com.edu;
class Table1{
	synchronized void printTable(int num) {
		for(int i=1;i<=10;i++) {
			System.out.println(num+"x"+i+"="+num*i);
		}
	}
} 
class MyThread1 extends Thread{
	Table1 table=new Table1();
	int num;
	public MyThread1(Table1 table,int num) {
		this.table=table;
		this.num=num;
	}
	public void run() {
		table.printTable(num);
	}
}


public class synchro {

	public static void main(String[] args) {
		Table1 table=new Table1();
		MyThread1 t1=new MyThread1(table,4);
		t1.start();
		

	}

}
