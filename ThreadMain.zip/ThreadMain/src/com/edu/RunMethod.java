package com.edu;


class Class2 implements Runnable{
    @Override
     public void run(){
        System.out.println("Run method");
   }
}

public class RunMethod{
public static void main(String args[]){   
      Class2 ob=new Class2();
        Thread tob=new Thread(ob);
        tob.start();
}
}


