package mypack;

public class VariableDemo1 {

	public static void main(String[] args) {
		int ival=12;
		float fval=56.34f;
		char ch='A';
		String s="Hello";
		System.out.println("int value is" +ival);
		System.out.println("float value is" +fval);
		System.out.println("character value is" +ch);
		System.out.println("string value is" +s);

	}

}
