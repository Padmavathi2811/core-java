package com.edu;

public class MainApp {

	public static void main(String[] args) {
		int a=10,b=0,c=0;
		
		System.out.println("Before division");
		try {
		c=a/b;
		}
		catch(ArithmeticException e) {
			System.out.println("e");
		
		}
		System.out.println("After division"+c);

	}

}
