package Mypack;

import java.util.Scanner;

public class FactorsofNumber {

	public static void main(String[] args) {
		int num,i;
		i=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("�nter the number: ");
		num=sc.nextInt();
		while(i<=num)
		{
			if(num%i==0)
			{
				System.out.println(i+"");
			}
			i++;
			
			
		}
		sc.close();
		

	}

}
