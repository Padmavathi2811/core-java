package com.edu;
import java.util.HashSet;
import java.util.Iterator;

public class HashSetclass {

	public static void main(String[] args) {
		HashSet<Integer> hsob=new HashSet
		<Integer>();
		hsob.add(56);
		hsob.add(65);
		hsob.add(83);
		hsob.add(12);
		hsob.add(39);
		hsob.add(88);
		System.out.println("hsob");
		Iterator<Integer> it=hsob.iterator();
		System.out.println("Elements of Hashset");
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
		

	}


