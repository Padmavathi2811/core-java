package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.entity.Authors;
import com.service.AuthorsService;

@RestController
public class AuthorsController {
	
	@Autowired
	private AuthorsService authorsService;
	
	@GetMapping("/getAllAuthors")
	public List<Authors> getAllAuthors()
	{
		return authorsService.getAllAuthors();
	}
	
	@PostMapping("/registerAuthor")
	public ResponseEntity<Authors> registerAuthor(@Valid @RequestBody Authors authors)
	{
		return new ResponseEntity<Authors>(authorsService.registerAuthor(authors), HttpStatus.CREATED);
	}
	
	@DeleteMapping("/deleteAuthorById/{authorid}")
	public ResponseEntity<String> deleteAuthorById(@PathVariable("authorid") Integer authorid)
	{
		authorsService.deleteAuthorById(authorid);
		return new ResponseEntity<String>("Author record is deleted",HttpStatus.OK);
	}
	
	@PutMapping("/updateAuthorById/{authorid}")
	public ResponseEntity<Authors> updateAuthor(@PathVariable("authorid") Integer authorid, @RequestBody Authors author)
	{
		return new ResponseEntity<Authors>(authorsService.updateAuthor(authorid,author),HttpStatus.OK);
		
	}

}
