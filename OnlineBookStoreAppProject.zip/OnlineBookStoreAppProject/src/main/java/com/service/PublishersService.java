package com.service;

import java.util.List;

import com.entity.Publishers;

public interface PublishersService {

	List<Publishers> getAllPublishers();

	Publishers registerPublisher(Publishers publishers);

	void deletePublisherById(Integer publisherid);

	Publishers updatePublisherById(Integer publisherid, Publishers publisher);

}
