package com.edu;
class Add{
	private int num1,num2,add;
	public void accept() {
		num1=23;
		num2=67;
}
	public void addition() {
		add=num1+num2;
	}
	public void display() {
		System.out.println("addition of "+num1 + "&" +num2 + " is "+add);
	}
}

public class AdditionMain {

	public static void main(String[] args) {
		Add obj=new Add();
		obj.accept();
		obj.addition();
		obj.display();
		
	
		
		

	}

}
