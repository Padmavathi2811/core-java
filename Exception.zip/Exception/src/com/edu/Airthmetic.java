package com.edu;

import java.util.Scanner;

public class Airthmetic {

	public static void main(String[] args) {
		int a,b,c=1;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a= ");
		a=sc.nextInt();
		System.out.println("Enter b= ");
		b=sc.nextInt();
		try {
		c=a/b;
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
		}
		{
		System.out.println("division= "+c);
		}
		

	}

}
