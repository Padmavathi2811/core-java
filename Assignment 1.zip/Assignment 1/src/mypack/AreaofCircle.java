package mypack;

import java.util.Scanner;

public class AreaofCircle {

	public static void main(String[] args) {
		float radius,areaf;
		radius=20;
		areaf=3.14149f*radius*radius;
		System.out.println("radius of circle= "+radius +" and the area is "+areaf + " squnits");

	}

}
