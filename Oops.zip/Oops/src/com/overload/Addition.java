package com.overload;
class Add{
	public void add(int i,int j) {
		int s=i+j;
		System.out.println("sum of integer numbers= "+s);
		
	}
	public void add(float i,float j) {
		float s=i+j;
		System.out.println("sum of floating numbers= "+s);
		
	}
	public void add(double i,double j) {
		double s=i+j;
		System.out.println("sum of double numbers= "+s);
	}
	
}

public class Addition {
	public static void main(String args[]) {
		Add aob=new Add();
		aob.add(3,5);
		aob.add(4.2f,5.7f);
		aob.add(3.3,2.8);
		
		
	}
	
	
	

}
