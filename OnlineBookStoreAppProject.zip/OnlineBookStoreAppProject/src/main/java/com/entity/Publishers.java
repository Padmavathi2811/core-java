package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;

@Entity
@SequenceGenerator(name = "publicseq" , initialValue = 1001)
public class Publishers {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "publicseq")
	private Integer publisherId;
	
	@NotBlank(message = "Publication name should not be blank")
	private String publicationName;
	
	//no argument constructor
	public Publishers() {
		super();
	}

	//getters and setters
	public Integer getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(Integer publisherId) {
		this.publisherId = publisherId;
	}

	public String getPublicationName() {
		return publicationName;
	}

	public void setPublicationName(String publicationName) {
		this.publicationName = publicationName;
	}
	
	
	

}
