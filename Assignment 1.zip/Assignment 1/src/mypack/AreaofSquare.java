package mypack;

public class AreaofSquare {

	public static void main(String[] args) {
		int side,area;
		side=20;
		area=side*side;
		System.out.println(" side of square= "+side +" and the area is "+area +" squnits");

	}

}

	


