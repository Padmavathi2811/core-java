package string.com;
import java.util.Scanner;
class WordCount1 {
	private String sent;
	private int cnt;
	
	public void inputString() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Sentence");
		sent=sc.nextLine();
	}
		public void countwordFunction() {
			for(int i=0;i<sent.length();i++) {
				char ch=sent.charAt(i);
				if(ch==' ') {
				
					cnt++;
			}
			}
			System.out.println("no of words= "+(cnt+1));
		

	}

}
public class WordCount{
	
	public static void main(String[]args) {
		WordCount1 ob=new WordCount1();
		ob.inputString();
		ob.countwordFunction();
	}
}
