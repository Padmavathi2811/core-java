package com.jdbc.edu;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteRecord {

	public static void main(String[] args) {
		String driver ="com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/padmavathidatabase";
		String un = "root";
		String pass = "root";
		Scanner sc=new Scanner(System.in);
		int eid = 0;
		
		try {
			
			Class.forName(driver);
			
			Connection conn=DriverManager.getConnection(url, un, pass);
			Statement st= conn.createStatement();

			System.out.println("Enter employee id");
			eid = sc.nextInt();
			
			String select="select * from employee where eid ="+eid;
ResultSet rs = st.executeQuery(select);
			
			if(rs.next()) { 
				
				String delete ="delete from employee where eid="+eid;
				System.out.println(delete);
				int retval=st.executeUpdate(delete);
				if(retval>0) {
					System.out.println("Record is deleted");
				}
				else {
					System.out.println("Some error occured not delete record");
				}
				
			}else {
				System.out.println(eid+" not exists in database updation not possible");
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
	
	

}
		

	


