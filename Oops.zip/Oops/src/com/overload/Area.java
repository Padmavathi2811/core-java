package com.overload;


class AreaCal
{
	public void area(int side)
	{
		int square=side*side;
		System.out.println("Area of square :"+square);
	}
	public void area(int l,int b)
	{
		int rectangle=l*b;
		System.out.println("Area of rectangle :"+rectangle);
	}
	public void area(float r)
	{
		float circle=3.141f*r*r;
		System.out.println("Area of a circle :"+circle);
	}
	public void area(float b,int h)
	{
		float triangle=0.5f*b*h;
		System.out.println("Area of a triangle :"+triangle);
	}
}

public class Area {

	public static void main(String[] args) {
		AreaCal aob=new AreaCal ();
		aob.area(10);
		aob.area(12,15);
		aob.area(3.2f);
		aob.area(5,6);
		
	}

}


