package mypack;

public class Multiply {

	public static void main(String[] args) {
		float num1,num2,ans;
		num1=56.3f;
	    num2=89.2f;
	    ans=num1*num2;
	    System.out.println("the product of "+num1+" and "+num2+" is " +ans);
	    

	}

}
