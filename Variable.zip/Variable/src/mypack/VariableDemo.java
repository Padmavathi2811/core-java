package mypack;

public class VariableDemo {

	public static void main(String[] args) {
		int age=20;
		System.out.println("age=" +age);

	}

}
