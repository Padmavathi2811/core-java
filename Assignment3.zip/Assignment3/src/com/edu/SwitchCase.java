package com.edu;
import java.util.Scanner;

public class SwitchCase {

	
		public static void main(String[] args) {
			int num1,num2,ans;
			String op;
			Scanner sc=new Scanner(System.in);
			System.out.println("enter two numbers");
			num1=sc.nextInt();
			num2=sc.nextInt();
			System.out.println("---menu---");
			System.out.println("enter add");
			System.out.println("enter sub");
			System.out.println("enter mul");
			System.out.println("enter div");
			op=sc.next();
			switch(op)
			{
			case "add":
				ans=num1+num2;
				System.out.println("enter sum"+ans);
				break;
			case "sub":
				ans=num1-num2;
				System.out.println("enter sub"+ans);
				break;
			case "mul":
				ans=num1*num2;
				System.out.println("enter mul"+ans);
				break;
			case "div":
				ans=num1/num2;
				System.out.println("enter div"+ans);
				break;
				default:
					System.out.println("invalid");
					
			
			}


		}

	

	}


