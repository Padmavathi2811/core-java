package mypack;

public class Division {

	public static void main(String[] args) {
 		float num1,num2,ans;
		num1=59.76f;
		num2=89.2f;
		ans=num2/num1;
		System.out.println("the quotient of " + num1 + " and " + num2 + " is " + ans);

	}

}
