package com.edu;
import java.util.Scanner;
class Rectangle{
	int length,breadth,area;
	void input() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Length and Breadth of Rectangle ");
		length=sc.nextInt();
		breadth=sc.nextInt();
		area=sc.nextInt();
	}
		void calculateArea(){
		area=length*breadth;
		}
		void display() {
			System.out.println("length= "+length + "breadth= "+breadth + "is" + "Area of Rectangle= "+area);
		}
		
public class MainClassRectangle {
	public static void main(String[]args) {
	System.out.println("you are in main method");
	Rectangle robj=new Rectangle ();
	robj.input();
	robj.calculateArea();
	robj.display();
}
	
	
}
}
		

	


