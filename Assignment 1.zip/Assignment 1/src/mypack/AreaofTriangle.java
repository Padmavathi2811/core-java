package mypack;

public class AreaofTriangle {

	public static void main(String[] args) {
		float base,height,area;
		base=12;
		height=15;
		area=(1/2f)*base*height;
		System.out.println("base of triangle= "+base + " and height of triangle= "+height + " is area of triangle:"+area +" squnits");
	

	}

}
