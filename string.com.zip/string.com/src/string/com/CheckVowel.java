package string.com;

public class CheckVowel {

	public static void main(String[] args) {
		String s="malathi";
		int count=0;
		System.out.println("num of char = "+s.length());
		System.out.println("char at particular position "+s.charAt(6));
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch=='a'|| ch=='e'|| ch=='i'|| ch=='o'|| ch=='u')
			{
				count++;
			}
		}
		System.out.println("num of vowels= " +count);
		}
		
		
		
		

	}


