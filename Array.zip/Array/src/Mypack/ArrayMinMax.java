package Mypack;

import java.util.Scanner;

public class ArrayMinMax {
public static void main(String[] args) {
		
		int ar[]=new int[5];
         Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter 5 numbers");
		for(int i=0;i<5;i++) {  
			ar[i]=sc.nextInt();
		}
		
		System.out.println("Entered elements are");
		for(int i=0;i<5;i++) {
		   System.out.println(ar[i]);
		}
		
		 
		
		int max=ar[0];  
		
		for(int i=1;i<ar.length;i++) {  
			if(ar[i]>max) { 
				max=ar[i]; 
			}
		}
		
		System.out.println("Largest of array element is "+max);
		
		
		
         int min=ar[0];  
		
		for(int i=1;i<ar.length;i++) {  
			if(ar[i]<min) { 
				min=ar[i]; 
			}
		}
		
		System.out.println("smallest of array element is "+min );
	}

}


