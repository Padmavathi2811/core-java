package com.edu;

public class TryUsingMultipleCatch {

	public static void main(String[] args) {
		int a=10,b=0,c=0;
		int arr[]=new int[4];
		System.out.println("Starting program ");
		try {
			c=a/b;
			arr[4]=67;
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		System.out.println("end of the program ");
		}

	}


