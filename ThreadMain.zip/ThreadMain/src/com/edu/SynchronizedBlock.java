package com.edu;
class Table{
	void printTable(int n) {
		synchronized(this) {
			System.out.println("name of the thread is synchronized block="+Thread.currentThread());
			for(int i=1;i<=0;i++) {
				System.out.println(n+"*"+i+"="+i*n);
			}
		}
		for(int j=1;j<=5;j++) {
			System.out.println("name of thread is outside side synchrinized block="+Thread.currentThread());
			System.out.println("edubridge");
		}
	}
}
class Thread1 extends Thread{
	Table table=new Table();
	int num;
	Thread1(Table table,int num){
		this.table=table;
		this.num=num;
	}
	@Override
	public void run() {
		table.printTable(num);
	}
	
	
class Thread2 extends Thread{
	Table table=new Table();
	int num;
	Thread2(Table table,int num){
		this.table=table;
		this.num=num;
	}
	@Override
	public void run() {
		table.printTable(num);
	}
	
	}
}
public class SynchronizedBlock {

	public static void main(String[] args) throws InterruptedException{
		Table table=new Table();
		Thread1 t1=new Thread1(table,4);
		t1.start();
		
	}
}